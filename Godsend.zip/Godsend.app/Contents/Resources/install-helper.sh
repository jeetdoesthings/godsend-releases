#!/bin/bash
set -e
RES_DIR="$(cd "$(dirname "$0")" && pwd)"
mkdir -p /Library/PrivilegedHelperTools
mkdir -p /Library/LaunchDaemons

cp "$RES_DIR/godsend-daemon" /Library/PrivilegedHelperTools/godsend-daemon
chown root:wheel /Library/PrivilegedHelperTools/godsend-daemon
chmod 755 /Library/PrivilegedHelperTools/godsend-daemon

launchctl bootout system /Library/LaunchDaemons/com.magcheat.daemon.plist 2>/dev/null || true
launchctl bootout system /Library/LaunchDaemons/com.godsend.daemon.plist 2>/dev/null || true
rm -f /Library/LaunchDaemons/com.magcheat.daemon.plist /Library/PrivilegedHelperTools/magcheat-daemon /var/run/magcheat.sock

cp "$RES_DIR/com.godsend.daemon.plist" /Library/LaunchDaemons/com.godsend.daemon.plist
chown root:wheel /Library/LaunchDaemons/com.godsend.daemon.plist
chmod 644 /Library/LaunchDaemons/com.godsend.daemon.plist
launchctl bootstrap system /Library/LaunchDaemons/com.godsend.daemon.plist
launchctl kickstart -p system/com.godsend.daemon 2>/dev/null || true
