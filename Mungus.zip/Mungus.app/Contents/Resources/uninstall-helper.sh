#!/bin/bash
launchctl bootout system /Library/LaunchDaemons/com.magcheat.daemon.plist 2>/dev/null || true
rm -f /Library/LaunchDaemons/com.magcheat.daemon.plist
rm -f /Library/PrivilegedHelperTools/magcheat-daemon
rm -f /var/run/magcheat.sock
