#!/bin/bash
set -e
RES_DIR="$(cd "$(dirname "$0")" && pwd)"
mkdir -p /Library/PrivilegedHelperTools
mkdir -p /Library/LaunchDaemons

cp "$RES_DIR/magcheat-daemon" /Library/PrivilegedHelperTools/magcheat-daemon
chown root:wheel /Library/PrivilegedHelperTools/magcheat-daemon
chmod 755 /Library/PrivilegedHelperTools/magcheat-daemon

launchctl bootout system /Library/LaunchDaemons/com.magcheat.daemon.plist 2>/dev/null || true
cp "$RES_DIR/com.magcheat.daemon.plist" /Library/LaunchDaemons/com.magcheat.daemon.plist
chown root:wheel /Library/LaunchDaemons/com.magcheat.daemon.plist
chmod 644 /Library/LaunchDaemons/com.magcheat.daemon.plist
launchctl bootstrap system /Library/LaunchDaemons/com.magcheat.daemon.plist
